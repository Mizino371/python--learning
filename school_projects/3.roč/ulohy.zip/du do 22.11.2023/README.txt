Vytvorte program, v ktorom sa najprv v strede
obrazovky nakreslí čiara. Ak klikneme myšou nad túto
čiaru, bude program kresliť modrý štvorec, 
ak klikneme pod túto čiaru, bude program kresliť žltý kruh.
